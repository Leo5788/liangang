import { motion } from 'framer-motion';

// 公司动态数据
const newsItems = [
  {
    id: 1,
    title: "我公司荣获2024年度最佳紧固件供应商称号",
    date: "2024-06-15",
    summary: "在行业年度评选中，我公司凭借优质产品和卓越服务，荣获由中国机械工业协会颁发的'2024年度最佳紧固件供应商'称号。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=company+award+ceremony+industrial+setting&sign=e7f805a11304f8498edba4d2c809fda7"
  },
  {
    id: 2,
    title: "新生产线投产，年产能提升50%",
    date: "2024-04-28",
    summary: "公司投资新建的智能化生产线正式投产，采用先进自动化设备，年产能提升50%，可满足更多客户的大规模采购需求。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=industrial+production+line+fasteners+manufacturing&sign=eddf06ed0fa1a84b86831a580dab53ee"
  },
  {
    id: 3,
    title: "参加2024上海国际紧固件展览会",
    date: "2024-03-10",
    summary: "我公司将参加于2024年3月15-17日举办的上海国际紧固件展览会，展位号E3馆2318，欢迎新老客户莅临参观指导。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=industrial+exhibition+booth+fasteners+display&sign=d6aebc6d661f0e41e4faaa9ec37bbd45"
  }
];

export default function NewsSection() {
  return (
    <section id="news" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">公司动态</h2>
            <p className="text-gray-600 max-w-2xl">
              了解公司最新动态、行业资讯和产品信息，把握紧固件行业发展趋势
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <a href="#" className="text-blue-900 hover:text-orange-500 font-medium flex items-center group"> 
              查看全部动态 
              <i className="fa-solid fa-long-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
            </a>
          </div>
        </div>
        
        {/* 新闻列表 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration:0.5, delay: index * 0.1 }}
              className="bg-gray-50 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all group"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end">
                  <div className="p-4 text-white">
                    <span className="text-sm font-medium">{item.date}</span>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <i className="fa-regular fa-calendar mr-2"></i>
                  <span>{item.date}</span>
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-3 group-hover:text-orange-500 transition-colors">
                  {item.title}
                </h3>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {item.summary}
                </p>
                <a href="#" className="inline-flex items-center text-blue-900 hover:text-orange-500 font-medium group">
                  阅读更多
                  <i className="fa-solid fa-arrow-right ml-2 text-sm group-hover:translate-x-1 transition-transform"></i>
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}