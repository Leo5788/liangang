import { motion } from 'framer-motion';

export default function AboutSection() {
  return (
    <section id="about" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="rounded-xl overflow-hidden shadow-xl"
            >
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=industrial+factory+interior+manufacturing+fasteners&sign=628e82173aad02962a5dd66ea0dfcf8a" 
                alt="公司厂房" 
                className="w-full h-auto"
              />
            </motion.div>
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-lg hidden md:block">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-900 text-white p-3 rounded-full">
                  <i className="fa-solid fa-trophy text-2xl"></i>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-900">15+</div>
                  <div className="text-gray-600">行业经验</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="inline-block bg-blue-100 text-blue-900 text-sm font-medium px-3 py-1 rounded-full mb-4">
                关于我们
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6">
                专业紧固件制造商<br />
                <span className="text-orange-500">15年行业经验</span>
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                我公司成立于2009年，是一家专业从事高强度紧固件研发、生产和销售的高新技术企业。我们拥有先进的生产设备和检测仪器，严格的质量控制体系，确保为客户提供高品质的产品和服务。
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                产品广泛应用于机械制造、汽车工业、建筑工程、新能源等领域，客户遍布全国各地，并出口到欧美、东南亚等多个国家和地区。
              </p>
              
              {/* 公司优势 */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="flex items-start">
                  <div className="bg-blue-100 text-blue-900 p-2 rounded-lg mr-4">
                    <i className="fa-solid fa-check"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-blue-900 mb-1">品质保证</h3>
                    <p className="text-gray-600 text-sm">严格质量控制体系</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 text-blue-900 p-2 rounded-lg mr-4">
                    <i className="fa-solid fa-check"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-blue-900 mb-1">技术先进</h3>
                    <p className="text-gray-600 text-sm">先进生产工艺</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 text-blue-900 p-2 rounded-lg mr-4">
                    <i className="fa-solid fa-check"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-blue-900 mb-1">定制服务</h3>
                    <p className="text-gray-600 text-sm">满足特殊需求</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 text-blue-900 p-2 rounded-lg mr-4">
                    <i className="fa-solid fa-check"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-blue-900 mb-1">快速交货</h3>
                    <p className="text-gray-600 text-sm">高效供应链管理</p>
                  </div>
                </div>
              </div>
              
              <button className="bg-blue-900 hover:bg-blue-800 text-white px-8 py-3 rounded-full transition-all inline-flex items-center">
                <i className="fa-solid fa-users mr-2"></i>
                了解更多公司信息
              </button>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}