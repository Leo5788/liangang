import { motion } from 'framer-motion';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-blue-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* 公司信息 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-2xl font-bold flex items-center mb-6">
              <i className="fa-solid fa-bolt mr-2 text-orange-500"></i>
              <span>FastTech</span>
            </div>
            <p className="text-blue-200 mb-6">
              专业紧固件制造商，15年行业经验，为客户提供高品质的产品和服务。
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-blue-800 hover:bg-blue-700 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <i className="fa-brands fa-weixin"></i>
              </a>
              <a href="#" className="bg-blue-800 hover:bg-blue-700 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors"> 
                <i className="fa-brands fa-weibo"></i>
              </a>
              <a href="#" className="bg-blue-800 hover:bg-blue-700 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <i className="fa-brands fa-linkedin"></i>
              </a>
              <a href="#" className="bg-blue-800 hover:bg-blue-700 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <i className="fa-brands fa-youtube"></i>
              </a>
            </div>
          </motion.div>
          
          {/* 快速链接 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h3 className="text-lg font-bold mb-6">快速链接</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">首页</a></li>
              <li><a href="#products" className="text-blue-200 hover:text-orange-500 transition-colors">产品中心</a></li>
              <li><a href="#news" className="text-blue-200 hover:text-orange-500 transition-colors">公司动态</a></li>
              <li><a href="#about" className="text-blue-200 hover:text-orange-500 transition-colors">关于我们</a></li>
              <li><a href="#contact" className="text-blue-200 hover:text-orange-500 transition-colors">联系我们</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">加入我们</a></li>
            </ul>
          </motion.div>
          
          {/* 产品系列 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="text-lg font-bold mb-6">产品系列</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">螺栓类</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">螺母类</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">螺丝类</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">垫圈类</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">铆钉类</a></li>
              <li><a href="#" className="text-blue-200 hover:text-orange-500 transition-colors">定制产品</a></li>
            </ul>
          </motion.div>
          
          {/* 联系信息 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h3 className="text-lg font-bold mb-6">联系我们</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fa-solid fa-map-marker-alt text-orange-500 mt-1 mr-3"></i>
                <span className="text-blue-200">浙江省宁波市鄞州区工业园区88号</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-phone text-orange-500 mr-3"></i>
                <span className="text-blue-200">0574-88888888</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-envelope text-orange-500 mr-3"></i>
                <span className="text-blue-200">info@fasttech.com</span>
              </li>
              <li className="flex items-center">
                <i className="fa-regular fa-clock text-orange-500 mr-3"></i>
                <span className="text-blue-200">周一至周五: 8:00 - 17:30</span>
              </li>
            </ul>
          </motion.div>
        </div>
        
        <div className="border-t border-blue-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-blue-300 text-sm mb-4 md:mb-0">
              &copy; {currentYear} FastTech 紧固件有限公司. 保留所有权利.
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-blue-300 hover:text-orange-500 text-sm transition-colors">隐私政策</a>
              <a href="#" className="text-blue-300 hover:text-orange-500 text-sm transition-colors">使用条款</a>
              <a href="#" className="text-blue-300 hover:text-orange-500 text-sm transition-colors">网站地图</a>
              <a href="#" className="text-blue-300 hover:text-orange-500 text-sm transition-colors">法律声明</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}