import { useState } from 'react';
import { motion } from 'framer-motion';

// 产品数据
const products = [
  {
    id: 1,
    name: "高强度螺栓",
    category: "螺栓类",
    description: "采用优质合金钢制造，适用于高强度连接需求，广泛应用于机械制造和建筑行业。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=high+strength+bolts+industrial+fasteners&sign=7bbe94719b1ffad7bbcf87fe2afc17aa"
  },
  {
    id: 2,
    name: "不锈钢螺母",
    category: "螺母类",
    description: "耐腐蚀不锈钢材质，精密加工，确保连接紧固性和耐久性，适用于各种环境。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=stainless+steel+nuts+industrial+fasteners&sign=7ad1982e5e13d7cb309b203e47781148"
  },
  {
    id: 3,
    name: "自攻螺丝",
    category: "螺丝类",
    description: "尖端设计，易于安装，适用于金属薄板和塑料材料，提供可靠的紧固效果。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=self-tapping+screws+industrial+fasteners&sign=a6311ba8c2be457feabd3a0fe5f60d58"
  },
  {
    id: 4,
    name: "膨胀螺栓",
    category: "螺栓类",
    description: "适用于混凝土、砖石等基材，安装简便，提供强大的承载能力，安全可靠。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=expansion+bolts+industrial+fasteners&sign=e535cfe3701247a81c7cd6c6c455a190"
  }
];

// 产品分类
const categories = [
  { id: "all", name: "全部产品" },
  { id: "螺栓类", name: "螺栓类" },
  { id: "螺母类", name: "螺母类" },
  { id: "螺丝类", name: "螺丝类" },
  { id: "垫圈类", name: "垫圈类" }
];

export default function ProductSection() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedProduct, setSelectedProduct] = useState(null);
  
  // 根据分类筛选产品
  const filteredProducts = activeCategory === "all" 
    ? products 
    : products.filter(product => product.category === activeCategory);
  
  return (
    <section id="products" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">我们的产品系列</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            提供各类高品质紧固件产品，满足不同行业的专业需求，所有产品均通过严格质量检测
          </p>
        </div>
        
        {/* 产品分类 */}
        <div className="flex overflow-x-auto pb-4 mb-8 gap-2 justify-center">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-2 rounded-full whitespace-nowrap transition-all ${
                activeCategory === category.id
                  ? "bg-blue-900 text-white shadow-md"
                  : "bg-white text-blue-900 hover:bg-blue-50"
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* 产品展示 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all group cursor-pointer"
              onClick={() => setSelectedProduct(product)}
            >
              <div className="relative overflow-hidden h-48">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute top-3 left-3 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded">
                  {product.category}
                </div>
              </div>
              <div className="p-5">
                <h3 className="text-xl font-bold text-blue-900 mb-2 group-hover:text-orange-500 transition-colors">
                  {product.name}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-blue-900 font-bold">查看详情</span>
                  <i className="fa-solid fa-arrow-right text-orange-500 group-hover:translate-x-1 transition-transform"></i>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* 查看更多按钮 */}
        <div className="text-center mt-12">
          <button className="border-2 border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white px-8 py-3 rounded-full transition-all font-medium">
            查看全部产品 <i className="fa-solid fa-arrow-right ml-2"></i>
          </button>
        </div>
      </div>
      
      {/* 产品详情模态框 */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onClick={() => setSelectedProduct(null)}>
          <div 
            className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-end p-4">
              <button 
                onClick={() => setSelectedProduct(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <i className="fa-solid fa-times text-xl"></i>
              </button>
            </div>
            <div className="grid md:grid-cols-2 gap-6 p-4 md:p-8">
              <div className="rounded-lg overflow-hidden">
                <img 
                  src={selectedProduct.image} 
                  alt={selectedProduct.name}
                  className="w-full h-auto object-cover"
                />
              </div>
              <div>
                <div className="inline-block bg-blue-100 text-blue-900 text-sm font-medium px-3 py-1 rounded-full mb-4">
                  {selectedProduct.category}
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-blue-900 mb-4">
                  {selectedProduct.name}
                </h2>
                <p className="text-gray-600 mb-6">
                  {selectedProduct.description}
                </p>
                <div className="space-y-4 mb-8">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">材质</span>
                    <span className="font-medium">优质合金钢</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">标准</span>
                    <span className="font-medium">ISO 898-1</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">强度等级</span>
                    <span className="font-medium">8.8级 / 10.9级</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">表面处理</span>
                    <span className="font-medium">镀锌 / 氧化发黑</span>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-full transition-all">
                    <i className="fa-solid fa-shopping-cart mr-2"></i> 加入询价单
                  </button>
                  <button className="border border-blue-900 text-blue-900 hover:bg-blue-50 px-6 py-3 rounded-full transition-all">
                    <i className="fa-solid fa-file-pdf mr-2"></i> 下载规格书
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}