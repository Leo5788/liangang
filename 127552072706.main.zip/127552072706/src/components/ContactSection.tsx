import { motion } from 'framer-motion';

export default function ContactSection() {
  return (
    <section id="contact" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">联系我们</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            无论您有任何问题或需求，我们的团队将竭诚为您提供专业的服务和支持
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* 联系信息 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-gray-50 p-8 rounded-2xl"
          >
            <h3 className="text-2xl font-bold text-blue-900 mb-6">联系方式</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-blue-100 text-blue-900 p-3 rounded-lg mr-4">
                  <i className="fa-solid fa-map-marker-alt"></i>
                </div>
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">公司地址</h4>
                  <p className="text-gray-600">浙江省宁波市鄞州区工业园区88号</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-blue-100 text-blue-900 p-3 rounded-lg mr-4">
                  <i className="fa-solid fa-phone"></i>
                </div>
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">联系电话</h4>
                  <p className="text-gray-600">0574-88888888</p>
                  <p className="text-gray-600">138-8888-8888</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-blue-100 text-blue-900 p-3 rounded-lg mr-4">
                  <i className="fa-solid fa-envelope"></i>
                </div>
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">电子邮箱</h4>
                  <p className="text-gray-600">info@fasttech.com</p>
                  <p className="text-gray-600">sales@fasttech.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-blue-100 text-blue-900 p-3 rounded-lg mr-4">
                  <i className="fa-regular fa-clock"></i>
                </div>
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">工作时间</h4>
                  <p className="text-gray-600">周一至周五: 8:00 - 17:30</p>
                  <p className="text-gray-600">周六: 9:00 - 12:00 (仅销售)</p>
                </div>
              </div>
            </div>
            
            <div className="mt-10">
              <h4 className="font-bold text-blue-900 mb-4">关注我们</h4>
              <div className="flex space-x-4">
                <a href="#" className="bg-blue-900 hover:bg-blue-800 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <i className="fa-brands fa-weixin"></i>
                </a>
                <a href="#" className="bg-blue-900 hover:bg-blue-800 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <i className="fa-brands fa-weibo"></i>
                </a>
                <a href="#" className="bg-blue-900 hover:bg-blue-800 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <i className="fa-brands fa-linkedin"></i>
                </a>
                <a href="#" className="bg-blue-900 hover:bg-blue-800 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <i className="fa-brands fa-youtube"></i>
                </a>
              </div>
            </div>
            
            <div className="mt-10">
              <div className="rounded-xl overflow-hidden h-48 bg-gray-200 flex items-center justify-center">
                <div className="text-center p-4">
                  <i className="fa-solid fa-map-marked-alt text-4xl text-gray-400 mb-2"></i>
                  <p className="text-gray-500">公司位置地图</p>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* 联系表单 */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <form className="bg-white border border-gray-200 p-8 rounded-2xl shadow-sm">
              <h3 className="text-2xl font-bold text-blue-900 mb-6">发送消息</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">姓名</label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    placeholder="请输入您的姓名"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">邮箱</label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    placeholder="请输入您的邮箱"
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">公司名称</label>
                <input
                  type="text"
                  id="company"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  placeholder="请输入您的公司名称"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">主题</label>
                <select
                  id="subject"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                >
                  <option value="">请选择咨询主题</option>
                  <option value="product">产品咨询</option>
                  <option value="price">价格咨询</option>
                  <option value="technical">技术支持</option>
                  <option value="cooperation">商务合作</option>
                  <option value="other">其他问题</option>
                </select>
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">留言内容</label>
                <textarea
                  id="message"
                  rows={5}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  placeholder="请输入您的留言内容"
                ></textarea>
              </div>
              
              <div className="mb-6">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-600">
                    我同意贵公司的隐私政策，并愿意接收相关产品和服务的信息
                  </span>
                </label>
              </div>
              
              <button
                type="submit"
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-medium py-3 px-6 rounded-lg transition-all transform hover:scale-[1.02]"
              >
                发送消息
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}