import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={cn(
        "fixed w-full z-50 transition-all duration-300",
        isScrolled 
          ? "bg-white shadow-md py-2" 
          : "bg-transparent py-4"
      )}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-2xl font-bold text-blue-900 flex items-center">
              <i className="fa-solid fa-bolt mr-2 text-orange-500"></i>
              <span>FastTech</span>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-blue-900 hover:text-orange-500 font-medium transition-colors">首页</a>
            <a href="#products" className="text-blue-900 hover:text-orange-500 font-medium transition-colors">产品</a>
            <a href="#news" className="text-blue-900 hover:text-orange-500 font-medium transition-colors">公司动态</a>
            <a href="#about" className="text-blue-900 hover:text-orange-500 font-medium transition-colors">关于我们</a>
            <a href="#contact" className="text-blue-900 hover:text-orange-500 font-medium transition-colors">联系我们</a>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-full transition-all transform hover:scale-105">
              立即咨询
            </button>
          </nav>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-blue-900 hover:text-orange-500"
            >
              <i className="fa-solid fa-bars text-xl"></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
            <a href="#" className="text-blue-900 hover:text-orange-500 py-2 border-b border-gray-100">首页</a>
            <a href="#products" className="text-blue-900 hover:text-orange-500 py-2 border-b border-gray-100">产品</a>
            <a href="#news" className="text-blue-900 hover:text-orange-500 py-2 border-b border-gray-100">公司动态</a>
            <a href="#about" className="text-blue-900 hover:text-orange-500 py-2 border-b border-gray-100">关于我们</a>
            <a href="#contact" className="text-blue-900 hover:text-orange-500 py-2 border-b border-gray-100">联系我们</a>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-full transition-all">
              立即咨询
            </button>
          </div>
        </div>
      )}
    </header>
  );
}